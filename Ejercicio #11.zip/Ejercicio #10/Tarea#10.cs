﻿Console.WriteLine("Por favor, ingrese su edad");
int edad=Convert.ToInt32(Console.ReadLine());
do
{
    if (edad <= 0 || edad >100)
    {
        Console.WriteLine("Edad incorrecta, vuelva a ingresarla");
        edad=Convert.ToInt32(Console.ReadLine());
    }
} while (edad <= 0 || edad >100);
Console.WriteLine("Su edad esta correcta");

Console.WriteLine("Ingrese un numero para mostrarle sus multiplicaciones del 1 al 10");
int resultado;
int numero = Convert.ToInt32(Console.ReadLine());

for (int multiplicaciones = 1; multiplicaciones < 11; multiplicaciones++)
{
    resultado=numero*multiplicaciones;
    Console.WriteLine(numero+"*"+multiplicaciones+"="+resultado);
}