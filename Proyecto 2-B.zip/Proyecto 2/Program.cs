﻿
public class Vehiculo
{
    public string marca;
    public string color;
    public string placa;
    public string tipoVehiculo;
    public int horaEntrada;

    /// <summary>
    /// La clase vehiculo es la que representara a todos los vehiculos en el parqueo. Los atributos ayudaran a hacer cada instancia unica y a poder ubicar a 
    /// Vehiculos especificos.
    /// </summary>
    /// <param name="marca">Determina la marca del vehiculo, es un string.</param>
    /// <param name="color">Determina el color del vehiculo, es un string.</param>
    /// <param name="placa">Determina la placa del vehiculo y usa la nomenclatura guatemalateca. Es un string</param>
    /// <param name="tipoVehiculo">Determina el tipo de vehiculo que es la clase, solo puede ser SUV, Sedan y Moto. Es un string.</param>
    /// <param name="horaEntrada">Numero entre 6 y 20. Es un int.</param>
    public Vehiculo(string marca, string color, string placa, string tipoVehiculo, int horaEntrada)
    {
        this.marca = marca;
        this.color = color;
        this.placa = placa;
        this.tipoVehiculo = tipoVehiculo;
        this.horaEntrada = horaEntrada;
    }
    /// <summary>
    /// El procedimiento "mostrar", mostrara de manera ordenada los atributos de la instancia que se pida.
    /// </summary>
    public void mostrar()
    {

        Console.WriteLine($"Info del Vehiculo: \nMarca: {marca}\nColor: {color}\nPlaca: {placa}\nTipo de Vehiculo: {tipoVehiculo}\nHora de entrada: {horaEntrada}");
    }
    /// <summary>
    /// La funcion PagoParqueo calculara la cantidad de dinero que el vehiculo debera pagar dependiendo del tiempo de estadia del vehiculo, el cual es un 
    /// numero aleatorio entre 0 y 24-horaEntrada, este se almacenara en la cariable estadia.
    /// </summary>
    /// <returns>Si  estadia es menor o igual a 1, retorna 0
    /// Si estadia es mayor que 1 y menor o igual a 4, retorna 15
    /// si estadia es mayor que 4 y menor o igual a 7, retorna 45
    /// Si estadia es mayor que 7 y menor o igual a 12, retorna 60
    /// Si estadia es mayor que 12 y menor o igual a 24, retorna 150</returns>
    public int PagoParqueo()
    {
        Random rnd = new Random();
        int rango = 24 - horaEntrada;
        int estadia = rnd.Next(0, rango + 1);
        int x;
        if (estadia <= 1)
        {
            x = 0;
        }
        else if (estadia > 1 && estadia <= 4)
        {
            x = 15;
        }
        else if (estadia > 4 && estadia <= 7)
        {
            x = 45;
        }
        else if (estadia > 7 && estadia <= 12)
        {
            x = 60;
        }
        else if (estadia > 12 && estadia <= 24)
        {
            x = 150;
        }
        else
        {
            x = 0;
        }
        return x;
    }
}



class Program
{
    /// <summary>
    /// Convierte un numero a una letra usando el indice de una lista de letras.
    /// </summary>
    /// <param name="numero">Int que se ingresara para convertirlo en una letra.</param>
    /// <returns>Retorna una letra segun el indice que corresponde al numero que se ingreso.</returns>
    public static string numALetra(int numero)
    {
        string almacenador;
        char[] abecedario = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        almacenador = Convert.ToString(abecedario[numero]);
        return almacenador;
    }
    /// <summary>
    /// Convierte strings de un largo de 2 a una lista de ints. Haciendo uso de una lista con letras, identifica el indice de la letra que se esta proveyendo y 
    /// agrega el indice de la letra a la lista. En caso de ser un numero, convierte el string del numero a un int y lo agrega a la lista.
    /// </summary>
    /// <param name="codigo">String que posee una letra y un numero.</param>
    /// <returns>Retorna una lista de ints con un largo de 2.</returns>
    public static int[] letraANum(string codigo)
    {
        int[] lista = new int[2];
        string mayus = codigo.ToUpper();
        char[] abecedario = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        for (int i = 0; i < mayus.Length; i++)

        {
            if (abecedario.Contains(codigo[i]) == true)
            {
                for (int j = 0; j < abecedario.Length; j++)
                {
                    if (codigo[i] == abecedario[j])
                    {
                        lista[i] = j;
                    }
                }
            }
            else if (abecedario.Contains(codigo[i]) == false)
            {
                string x = Convert.ToString(codigo[i]);
                lista[i] = int.Parse(x)-1;
            }
        }
        return lista;

    }
    /// <summary>
    /// Asigna los strings de "Moto", "SUV" y "Sedan" a cada espacio de la matriz de strings que se usara para identificar el tipo de cada parqueo. Usando la 
    /// cantidad de espacios de Moto y SUV, se calcula la cantidad de espacios Sedan.
    /// </summary>
    /// <param name="cantidadM">Cantidad de espacios de tipo moto dentro de la matriz</param>
    /// <param name="cantidadSU">Cantidad de espacio de tipo SUV dentro de la matriz</param>
    /// <param name="matrizT">La matriz en la que se asignaran los tipos de Vehiculo.</param>
    public static void asignarTipoParqueo(int cantidadM, int cantidadSU, string[,] matrizT)
    {
        int contador = 0;
        for (int i = 0; i < matrizT.GetLength(0); i++)
        {
            for (int j = 0; j < matrizT.GetLength(1); j++)
            {
                if (contador < cantidadM)
                {
                    matrizT[i, j] = "Moto";
                }
                else if (contador < cantidadM + cantidadSU && contador >= cantidadM)
                {
                    matrizT[i, j] = "SUV";
                }
                else if (contador >= cantidadM + cantidadSU)
                {
                    matrizT[i, j] = "Sedan";
                }
                contador += 1;
            }
        }
    }
    /// <summary>
    /// El procedimiento muestra los espacios libres en el estacionamiento para un tipo especifico de vehiculo.
    /// </summary>
    /// <param name="matrizR">Matriz de la clase Vehiculo qeu permite saber que espacios se encuentra libres dentro del parqueo</param>
    /// <param name="matrizT">Matriz de strings que permite saber que tipos de vehiculo se admiten en cada estacionamiento.</param>
    /// <param name="objeto">Objeto de tipo Vehiculo, usando su atributo tipoVehiculo se muestran como una "X" los espacios distintos al tipo del objeto.</param>
    public static void mostrarMatrizVisual(Vehiculo[,] matrizR, string[,] matrizT, Vehiculo objeto)
    {
        for (int i = 0; i < matrizR.GetLength(0); i++)
        {
            string almacenador = "[";
            for (int j = 0; j < matrizR.GetLength(1); j++)
            {
                if (matrizR[i, j] == null && matrizT[i, j] == objeto.tipoVehiculo)
                {
                    almacenador += " " + numALetra(i) + Convert.ToString(j + 1) + " ";
                }
                else
                {
                    almacenador += " X ";
                }
            }
            almacenador += "]";
            Console.WriteLine(almacenador);
        }
    }
    /// <summary>
    /// Procedimiento que permite ingresar un lote de vehiculos de X cantidad. Coloca los cehiculos de manera aleatoria en el parqueo hasta que no quede espacio.
    /// </summary>
    /// <param name="cantidad">Cantidad de vehiculos que se ingresara</param>
    /// <param name="matrizR">Matriz de strings que permite saber que tipos de vehiculo se admiten en cada estacionamiento.</param>
    /// <param name="matrizT">Objeto de tipo Vehiculo, usando su atributo tipoVehiculo se muestran como una "X" los espacios distintos al tipo del objeto.</param>
    public static void ingresarLote(int cantidad, Vehiculo[,] matrizR, string[,] matrizT)
    {
        Random rnd = new Random();
        string[] marcas = { "Honda", "Suzuki", "Toyota", "Hyundai", "Mazda" };
        string[] colores = { "Rojo", "Negro", "Azul", "Gris", "Blanco" };
        string[] tipos = { "Moto", "SUV", "Sedan" };
        string[] abecedario = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        for (int i = 0; i < cantidad; i++)
        {
            int contador1 = 0;
            bool seguir = false;
            string placaRnd = $"P{rnd.Next(0, 10)}{rnd.Next(0, 10)}{rnd.Next(0, 10)}{abecedario[rnd.Next(0, abecedario.Length)]}{abecedario[rnd.Next(0, abecedario.Length)]}{abecedario[rnd.Next(0, abecedario.Length)]}";
            Vehiculo vehiculoRnd = new Vehiculo(marcas[rnd.Next(0, marcas.Length)], colores[rnd.Next(0, colores.Length)], placaRnd, tipos[rnd.Next(0, tipos.Length)], rnd.Next(6, 21));
            do
            {
                int ind1 = rnd.Next(0, matrizR.GetLength(0));
                int ind2 = rnd.Next(0, matrizR.GetLength(1));
                if (matrizR[ind1, ind2] == null && matrizT[ind1, ind2] == vehiculoRnd.tipoVehiculo)
                {
                    matrizR[ind1, ind2] = vehiculoRnd;
                    contador1 += 1;
                    seguir = true;
                    Console.WriteLine($"Vehiculo #{i + 1}:\nPlaca: {vehiculoRnd.placa} Estacionamiento: {numALetra(ind1)}{ind2 + 1}");
                    break;
                }
                else
                {
                    contador1 += 1;
                }
            } while (seguir == false && contador1 < matrizR.Length);
            if (contador1 == matrizR.Length)
            {
                Console.WriteLine("El parqueo esta lleno y nose pueden seguir almacenando vehiculos");
                break;
            }
        }
    }
    /// <summary>
    /// Metodo usado para buscar un objeto Vehiculo en la matriz Vehiculo. Se usa su atributo placa para encontrar la instancia que posea la misma que el usuario
    /// indica.
    /// </summary>
    /// <param name="placa">Placa que se usara para buscar el Vehiculo en concreto.</param>
    /// <param name="matrizR">Matriz Vehiculo donde se buscara el objeto.</param>
    public static void buscarVehiculo(string placa, Vehiculo[,] matrizR)
    {
        string placaMayus = placa.ToUpper();
        bool encontrado = false;
        for (int i = 0; i < matrizR.GetLength(0); i++)
        {
            for (int j = 0; j < matrizR.GetLength(1); j++)
            {
                Vehiculo vehiculot = matrizR[i, j];
                if (vehiculot == null)
                {
                    continue;
                }
                else if (vehiculot.placa == placaMayus)
                {

                    vehiculot.mostrar();
                    encontrado = true;
                    Console.WriteLine($"El vehiculo se encuentra en el espacio: {numALetra(i)}{j + 1}");
                    break;
                }
            }
        }
        if (encontrado == false)
        {
            Console.WriteLine("No se encontro la placa solicitada");
        }
    }
    /// <summary>
    /// Procedimiento que calculara la cantidad de billetes de cada valor se deben retornar en caso de que se deba dar vuelto
    /// </summary>
    /// <param name="montoADevolver">Cantidad total que se debe devolver al usuario.</param>
    public static void calculoVuelto(int montoADevolver)
    {
        int vueltoPendiente = montoADevolver;
        int[] billetes = { 100, 50, 20, 10, 5 };
        string vuelto = "Su vuelto son: ";
        for (int i = 0; i < billetes.Length; i++)
        {
            int v = vueltoPendiente / billetes[i];
            if (v > 0)
            {
                vueltoPendiente -= v * billetes[i];
                vuelto += $"{v} billetes de {billetes[i]}\n";
            }
            else if (v <= 0)
            {
                continue;
            }
        }
        Console.WriteLine(vuelto);
    }
    
    static void Main()
    {
        ///Aca se ingresa los pisos habilitados al publico (Filas)   
        Console.WriteLine("Bienvenido a la gestion de parqueos \nPor favor ingrese las dimensiones de el parqueo \nCuantos pisos estan habilitados al público?");
        int pisos = Convert.ToInt32(Console.ReadLine());
        ///Se ingresa los estacionamientos por piso (Columnas)
        Console.WriteLine("Ahora indique cuantos estacionamientos hay por piso");
        int parqueos = Convert.ToInt32(Console.ReadLine());

        /// Se crean la matriz de tipo Vehiculo "torreParqueos" para almacenar los objetos y la matriz de tipo String "matrizTipos", que almacena el tipo de
        /// Vehiculo admitido en cada espacio del parqueo.
        Vehiculo[,] torreParqueos = new Vehiculo[pisos, parqueos];
        string[,] matrizTipos = new string[pisos, parqueos];

        ///Se piden el numero de parqueos para moto y SUV
        Console.WriteLine("Cuantos parqueos para motos hay?");
        int parqueoMoto = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Cuantos parqueos para SUV hay?");
        int parqueoSUV = Convert.ToInt32(Console.ReadLine());

        ///Se calculan los estacionamientos tipo Sedan a partir de los datos obtenidos arriba y se asigna la cantidad de parqueos de cada tipo a la matriz
        /// "matrizTipos"
        int parqueosSedan = (pisos * parqueos) - parqueoMoto - parqueoSUV;
        Console.WriteLine($"Teniendo esto en cuenta, habran {parqueosSedan} parqueos tipo Sedan.");
        asignarTipoParqueo(parqueoMoto, parqueoSUV, matrizTipos);

        ///Dentro de un do_while, se usa un case switch para mostrar las opciones que el usuario tiene en el menu y que se vuelva a mostrar tras seleccionar una
        ///opcion mientras se cumpla X condicion.
        Console.WriteLine("Con todo esto arreglado pasemos a las opciones del menu");
        int opcion;
        do
        {
            Console.WriteLine("MENU: \n1. Añadir un vehículo \n2. Añadir lote de vehículos \n3. Encontrar un vehiculo \n4. Retirar un vehiculo \n5. Salir \nEscriba el numero de la opcion que desea seleaccionar:");
            opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                ///En este case el usuario debe ingreasar los atrubutos del objeto Vehiculo que quiere agregar al parqueo. Tras ellos usando la funcion 
                /// mostrarMatrizVisual(), se mostraran los espacios que puede seleccionar y si el espacio es valido se agregara el vehiculo.
                case 1:
                    Console.WriteLine("Selecciono añadir un vehículo. Ingrese los datos del vehículo: \nMarca:");
                    string miMarca = Console.ReadLine();
                    Console.WriteLine("Color:");
                    string miColor = Console.ReadLine();
                    Console.WriteLine("Placa: (Ingrese solo caracteres en mayuscula y un maximo de 6 caracteres)");
                    string miPlaca = "P" + Console.ReadLine();
                    miPlaca = miPlaca.ToUpper();
                    Console.WriteLine("Tipo de Vehiculo: (Moto, SUV o Sedan)");
                    string miTipo = Console.ReadLine();
                    Console.WriteLine("Indique la hora en que entro: (De 6:00 a 20:00)");
                    int miHoraEntrada = Convert.ToInt32(Console.ReadLine());
                    Vehiculo miVehiculo = new Vehiculo(miMarca, miColor, miPlaca, miTipo, miHoraEntrada);
                    Console.WriteLine("Indique donde quiere estacionar su auto: (Solo puede estacionarse en todo parque que no tenga una X)");
                    mostrarMatrizVisual(torreParqueos, matrizTipos, miVehiculo);
                    string codigo;
                    int[] asignar;
                    do
                    {
                        Console.WriteLine("Ingrese el codigo del estacionamiento: (Ingrese la letra y numero del codigo)");
                        codigo = Console.ReadLine();
                    } while (codigo.Length != 2);

                    asignar = letraANum(codigo);
                    torreParqueos[asignar[0], asignar[1]] = miVehiculo;
                    Console.WriteLine("Se ingreso el vehiculo con exito.");
                    break;
                ///Al seleccionar esta opcion el usuario debera ingresar la cantidad de vehiculos que desea ingresar en el lote, para luego usar el metodo
                /// ingresarLote() para ello.
                case 2:
                    Console.WriteLine("Selecciono ingresar un lote de vehiculo, cuantos vehiculos desea ingresar?");
                    int cant = Convert.ToInt16(Console.ReadLine());
                    ingresarLote(cant, torreParqueos, matrizTipos);
                    Console.WriteLine("Vehiculos ingresados");
                    break;
                ///El usuario ingresara la placa del vehiculo con las debidas consideraciones y se usara el metodo buscarVehiculo() para buscarlo.
                case 3:
                    Console.WriteLine("Ingrese la placa que desea buscar: (por ejemplo, P123ABC)");
                    string respuesta = Console.ReadLine();
                    respuesta = respuesta.ToUpper();
                    buscarVehiculo(respuesta, torreParqueos);
                    break;
                /// El usuario ingresara el estacionamiento donde se ubica el vehiculo que desea retirar, a partir de eso se usara el metodo de la clase Vehiculo:
                /// PagoParqueo para calcular lo que se debe pagar. Luego se solicitara al usuario como desea pagar. Si elige pagar con tarjeta o sticker, solo se 
                /// mostrara un mensaje del pago y se retirara el vehiculo del parqueo. En caso de elegir efectivo, se vera si es necesario dar vuelto; en caso de ello 
                /// se usara el metodo calculoVuelto() para ver la cantidad de billetes de cada denominacion que se deben devolver.
                case 4:
                    int[] indRetirar;
                    Console.WriteLine("Selecciono retirar un vehiculo.");
                    do
                    {
                        Console.WriteLine("Ingrese el codigo del estacionamiento donde se encuentra el vehiculo que desea retirar: (Ingrese la letra y el numero del codigo)");
                        string codigoRetirar = Console.ReadLine();
                        codigoRetirar = codigoRetirar.ToUpper();
                        indRetirar = letraANum(codigoRetirar);
                    } while (torreParqueos[indRetirar[0], indRetirar[1]] ==null);
                    
                    int pago = torreParqueos[indRetirar[0], indRetirar[1]].PagoParqueo();
                    if (pago == 0)
                    {
                        Console.WriteLine("El parqueo es de cortesia, tenga un buen dia.");
                    }
                    else
                    {
                        Console.WriteLine($"El monto a pagar es de {pago} quetzales. Elija su opcion de pago:\nTarjeta / Sticker recargable(T) o Efectivo (E)");
                        string opcion2 = Console.ReadLine();
                        switch (opcion2)
                        {
                            case "T":
                                Console.WriteLine("Su pago se realizo exitosamente, se retirara el vehiculo.");
                                break;
                            case "E":
                                Console.WriteLine("Cuanto desea pagar? (Solo puede colocar montos que sean multiplos de 5)");
                                int monto = Convert.ToInt32(Console.ReadLine());
                                int vuelto = monto - pago;
                                if (vuelto == 0)
                                {
                                    Console.WriteLine("No hay necesidad de vuelto, tenga buen dia.");
                                }
                                else
                                {
                                    calculoVuelto(vuelto);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    torreParqueos[indRetirar[0], indRetirar[1]] = null;
                    Console.WriteLine("El vehiculo se retiro con exito.");
                    break;
                ///Para el case 5, el bucle do_while terminara si se selecciona.
                case 5:
                    break;
                ///Al seleccionar cualquier otro numero, el ciclo se repetira.
                default:
                    continue;
            }
        } while (opcion != 5);
        Console.WriteLine("Gracias por usar el programa");
    }
    
}   
